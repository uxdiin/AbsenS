# pendataanKarantina
kknkt
