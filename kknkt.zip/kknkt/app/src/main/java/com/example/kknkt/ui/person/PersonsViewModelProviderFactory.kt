package com.example.kknkt.ui.person

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.kknkt.repository.PersonsRepository

class PersonsViewModelProviderFactory(
    val personsRepository: PersonsRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return PersonViewModel(personsRepository) as T
    }
}