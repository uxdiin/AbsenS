package com.example.kknkt.repository

import com.example.kknkt.db.PersonDatabase
import com.example.kknkt.models.Person

class PersonsRepository(
    private val db: PersonDatabase
)   {
        suspend fun  upsert(person: Person) = db.getPersonDao().upsert(person)
        fun getAllPerson() = db.getPersonDao().getAllPerson()
        suspend fun deletePerson(person: Person) = db.getPersonDao().deletePerson(person)
    }