package com.example.kknkt.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase
import com.example.kknkt.models.Person

@Database(
    entities =  [Person::class],
    version = 1
)
abstract class PersonDatabase : RoomDatabase(){
    abstract fun getPersonDao(): PersonDAO

    companion object {
        @Volatile
        private var instance: PersonDatabase? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?: synchronized(LOCK) {
            instance ?: createDatabase(context).also { instance = it }
        }

        private fun createDatabase(context: Context) =
            databaseBuilder(
                context.applicationContext,
                PersonDatabase::class.java,
                "person_db.db"
            ).build()
    }
}