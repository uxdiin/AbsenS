package com.example.kknkt

import android.os.Bundle
import android.util.Log
import android.view.Menu
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.kknkt.db.PersonDatabase
import com.example.kknkt.repository.PersonsRepository
import com.example.kknkt.ui.person.PersonFragment
import com.example.kknkt.ui.person.PersonViewModel
import com.example.kknkt.ui.person.PersonsViewModelProviderFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: PersonViewModel
    lateinit var fabButtonClick: FabButtonClick

    private val TAG: String = "MainActivity"

    companion object{
        public var idFrom: Int?= null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val personsRepository = PersonsRepository(PersonDatabase(this))
        val viewModelProviderFactory = PersonsViewModelProviderFactory(personsRepository)
        viewModel = ViewModelProvider(this, viewModelProviderFactory).get(PersonViewModel::class.java)

        fabAdd.setOnClickListener {
            findNavController(R.id.nav_host_fragment).navigate(R.id.action_navigation_home_to_personAddUpdateFragment)
        }
//        val navView: BottomAppBar = findViewById(R.id.bottom_app_bar)

//        val navController = findNavController(R.id.nav_host_fragment)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        val appBarConfiguration = AppBarConfiguration(setOf(
//                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications))
//        setupActionBarWithNavController(navController, appBarConfiguration)
//        navView.setupWithNavController(navController)
//        bottom_app_bar.setupWithNavController(nav_host_fragment.findNavController())
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.bottom_nav_menu, menu)
        return true
    }

    public interface FabButtonClick {
        fun onClickFabAdd()
    }

    private fun setListener(intervace: FabButtonClick){
        fabButtonClick = intervace
    }





}
