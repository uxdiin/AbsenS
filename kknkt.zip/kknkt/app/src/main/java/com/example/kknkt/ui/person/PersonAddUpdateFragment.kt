package com.example.kknkt.ui.person

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.fragment.app.Fragment
import com.example.kknkt.R
import com.example.kknkt.models.Person
import kotlinx.android.synthetic.main.fragment_person_add_update.*
import java.util.*

class PersonAddUpdateFragment : Fragment() {

    val TAG: String? = "PersonAddUpdateFragment"

    private var person : Person? = null
    private val spinner: Spinner? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_person_add_update, container, false)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (person==null){
            person =  Person()
        }
        btnSave?.setOnClickListener {
            person?.name = edtNik.text.toString().trim()
            person?.ttl = edtTtl.text.toString().trim()
//            person?.gender =
            person?.address = edtAddress.text.toString().trim()
//            person?.
        }
        prepareDatePicker()
        prepareSpinner()
    }

    private fun prepareSpinner(){
        val spinner: Spinner? = view?.findViewById(R.id.genderSpinner)
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            requireActivity().applicationContext,
            R.array.genders_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner?.adapter = adapter
        }
        spinner?.setOnItemClickListener { parent, view, position, id ->
//            spinner?.setspinner[position]
        }
    }
    private fun prepareDatePicker(){
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        edtArrivalDate.setOnClickListener {
            Log.d(TAG,"terclick")
            var dpd = DatePickerDialog(requireActivity().applicationContext, DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                // Display Selected date in TextView
                edtArrivalDate.setText("" + dayOfMonth + " " + month + ", " + year)
            }, year, month, day)
            dpd.show()

        }
    }
}
