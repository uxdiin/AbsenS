package com.example.kknkt.ui.person

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AbsListView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kknkt.MainActivity
import com.example.kknkt.R
import com.example.kknkt.adapter.PersonsAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_person.*

class PersonFragment : Fragment(),MainActivity.FabButtonClick {

    lateinit var viewModel: PersonViewModel
    private lateinit var personsAdapter: PersonsAdapter

    val TAG = "PersonsFragment"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = (activity as MainActivity).viewModel
        setupRecyclerView()
        (activity as MainActivity).fabAdd.setOnClickListener {
            Log.d(TAG,"tercick")
            findNavController().navigate(R.id.action_navigation_home_to_personAddUpdateFragment)
        }
        personsAdapter.setOnClickListener {
            val bundle = Bundle().apply {
                putSerializable("person", it)
            }
            findNavController().navigate(
                R.id.action_navigation_home_to_formAddUpdatePersonActivity,
                bundle
            )
        }

        viewModel.getAllPerson().observe(viewLifecycleOwner, Observer { persons ->
            personsAdapter.differ.submitList(persons)
        })

    }


    private fun setupRecyclerView() {
        personsAdapter = PersonsAdapter()
        rvPerson.apply {
            adapter = personsAdapter
            layoutManager = LinearLayoutManager(activity)
        }
    }

    override fun onClickFabAdd() {

    }
}
