package com.example.kknkt.ui.person

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kknkt.repository.PersonsRepository
import kotlinx.coroutines.launch
import com.example.kknkt.models.Person

class PersonViewModel(
    private val personsRepository: PersonsRepository
) : ViewModel() {

    fun savePerson(person: Person) = viewModelScope.launch {
        personsRepository.upsert(person)
    }

    fun getAllPerson() = personsRepository.getAllPerson()

    fun deletePerson(person: Person) = viewModelScope.launch {
        personsRepository.deletePerson(person)
    }

}