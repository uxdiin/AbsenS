package com.example.kknkt.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.kknkt.models.Person

@Dao
interface PersonDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(person: Person): Long

    @Query("SELECT * FROM persons")
    fun getAllPerson(): LiveData<List<Person>>

    @Delete
    suspend fun deletePerson(person: Person)
}
